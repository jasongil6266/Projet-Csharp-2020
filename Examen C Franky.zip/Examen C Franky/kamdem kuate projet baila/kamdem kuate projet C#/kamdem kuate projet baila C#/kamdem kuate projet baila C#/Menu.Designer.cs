﻿namespace projet_sadou
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.gestionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Bienvenue = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Dashboard = new System.Windows.Forms.Label();
            this.Stock = new System.Windows.Forms.Label();
            this.Article = new System.Windows.Forms.Label();
            this.Categorie = new System.Windows.Forms.Label();
            this.Commande = new System.Windows.Forms.Label();
            this.Ajouter = new System.Windows.Forms.Label();
            this.Profil2 = new System.Windows.Forms.Label();
            this.Profil = new System.Windows.Forms.Label();
            this.Utilisateur = new System.Windows.Forms.Label();
            this.contextMenuStrip2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(115, 26);
            // 
            // gestionToolStripMenuItem
            // 
            this.gestionToolStripMenuItem.Name = "gestionToolStripMenuItem";
            this.gestionToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.gestionToolStripMenuItem.Text = "Gestion";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(168, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(974, 654);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Utilisateur);
            this.groupBox2.Controls.Add(this.Profil);
            this.groupBox2.Controls.Add(this.Profil2);
            this.groupBox2.Controls.Add(this.Ajouter);
            this.groupBox2.Controls.Add(this.Commande);
            this.groupBox2.Controls.Add(this.Categorie);
            this.groupBox2.Controls.Add(this.Article);
            this.groupBox2.Controls.Add(this.Stock);
            this.groupBox2.Controls.Add(this.Dashboard);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(2, 59);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 654);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // Bienvenue
            // 
            this.Bienvenue.AutoSize = true;
            this.Bienvenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bienvenue.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Bienvenue.Location = new System.Drawing.Point(314, 25);
            this.Bienvenue.Name = "Bienvenue";
            this.Bienvenue.Size = new System.Drawing.Size(90, 18);
            this.Bienvenue.TabIndex = 0;
            this.Bienvenue.Text = "Bienvenue,";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(839, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Profil";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.label1.Location = new System.Drawing.Point(19, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Gestion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.label3.Location = new System.Drawing.Point(73, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Commerial";
            // 
            // Dashboard
            // 
            this.Dashboard.AutoSize = true;
            this.Dashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashboard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.Dashboard.Location = new System.Drawing.Point(18, 129);
            this.Dashboard.Name = "Dashboard";
            this.Dashboard.Size = new System.Drawing.Size(85, 16);
            this.Dashboard.TabIndex = 2;
            this.Dashboard.Text = "Dashboard";
            // 
            // Stock
            // 
            this.Stock.AutoSize = true;
            this.Stock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.Stock.Location = new System.Drawing.Point(18, 163);
            this.Stock.Name = "Stock";
            this.Stock.Size = new System.Drawing.Size(35, 13);
            this.Stock.TabIndex = 3;
            this.Stock.Text = "Stock";
            // 
            // Article
            // 
            this.Article.AutoSize = true;
            this.Article.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Article.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.Article.Location = new System.Drawing.Point(60, 184);
            this.Article.Name = "Article";
            this.Article.Size = new System.Drawing.Size(43, 13);
            this.Article.TabIndex = 4;
            this.Article.Text = "Article";
            this.Article.Click += new System.EventHandler(this.Article_Click);
            // 
            // Categorie
            // 
            this.Categorie.AutoSize = true;
            this.Categorie.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categorie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.Categorie.Location = new System.Drawing.Point(60, 220);
            this.Categorie.Name = "Categorie";
            this.Categorie.Size = new System.Drawing.Size(61, 13);
            this.Categorie.TabIndex = 5;
            this.Categorie.Text = "Categorie";
            // 
            // Commande
            // 
            this.Commande.AutoSize = true;
            this.Commande.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.Commande.Location = new System.Drawing.Point(18, 267);
            this.Commande.Name = "Commande";
            this.Commande.Size = new System.Drawing.Size(60, 13);
            this.Commande.TabIndex = 6;
            this.Commande.Text = "Commande";
            // 
            // Ajouter
            // 
            this.Ajouter.AutoSize = true;
            this.Ajouter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ajouter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.Ajouter.Location = new System.Drawing.Point(60, 294);
            this.Ajouter.Name = "Ajouter";
            this.Ajouter.Size = new System.Drawing.Size(47, 13);
            this.Ajouter.TabIndex = 7;
            this.Ajouter.Text = "Ajouter";
            this.Ajouter.Click += new System.EventHandler(this.Ajouter_Click);
            // 
            // Profil2
            // 
            this.Profil2.AutoSize = true;
            this.Profil2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Profil2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(167)))), ((int)(((byte)(171)))));
            this.Profil2.Location = new System.Drawing.Point(18, 384);
            this.Profil2.Name = "Profil2";
            this.Profil2.Size = new System.Drawing.Size(35, 15);
            this.Profil2.TabIndex = 8;
            this.Profil2.Text = "Profil";
            // 
            // Profil
            // 
            this.Profil.AutoSize = true;
            this.Profil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Profil.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.Profil.Location = new System.Drawing.Point(60, 414);
            this.Profil.Name = "Profil";
            this.Profil.Size = new System.Drawing.Size(36, 13);
            this.Profil.TabIndex = 9;
            this.Profil.Text = "Profil";
            // 
            // Utilisateur
            // 
            this.Utilisateur.AutoSize = true;
            this.Utilisateur.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Utilisateur.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(2)))), ((int)(((byte)(81)))), ((int)(((byte)(120)))));
            this.Utilisateur.Location = new System.Drawing.Point(60, 445);
            this.Utilisateur.Name = "Utilisateur";
            this.Utilisateur.Size = new System.Drawing.Size(64, 13);
            this.Utilisateur.TabIndex = 10;
            this.Utilisateur.Text = "Utilisateur";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(71)))));
            this.ClientSize = new System.Drawing.Size(1137, 712);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Bienvenue);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.contextMenuStrip2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem gestionToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label Utilisateur;
        private System.Windows.Forms.Label Profil;
        private System.Windows.Forms.Label Profil2;
        private System.Windows.Forms.Label Ajouter;
        private System.Windows.Forms.Label Commande;
        private System.Windows.Forms.Label Categorie;
        private System.Windows.Forms.Label Article;
        private System.Windows.Forms.Label Stock;
        private System.Windows.Forms.Label Dashboard;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Bienvenue;
        private System.Windows.Forms.Label label2;
    }
}